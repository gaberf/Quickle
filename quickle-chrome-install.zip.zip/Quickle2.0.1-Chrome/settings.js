let settingsbutton = document.getElementById('settings-btn');
settingsbutton.style.backgroundColor = '#e8e8e8';