let homebutton = document.getElementById('home-btn');
homebutton.style.backgroundColor = '#e8e8e8';